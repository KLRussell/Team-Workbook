select
	Source_TBL,
	Source_ID,
	Vendor,
	BAN,
	BTN,
	WTN,
	Circuit_ID,
	Max_CNR_Date,
	Cost_Start_Date,
	Max_Cost_Date,
	Priority,
	Tag,
	Previous_Result,
	Audit_Result

from [TBL]

where
	Audit_Result NOT IN ('Billing Added', 'Disconnected', 'Mapped', 'Changed Mapping', 'Timing')